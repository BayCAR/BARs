generate_cluster_data <- function(n_ids = 300, time_points = 10, n_clusters = 2, 
                                 sigma = 0.5, seed = 123) {
  set.seed(seed)
  
  # Generate cluster-specific parameters
  true_beta <- matrix(NA, nrow = 4, ncol = n_clusters)
  true_sd <- rep(sigma, n_clusters)
  
  # Create distinct polynomial patterns for each cluster
  if (n_clusters == 1) {
    true_beta[,1] <- c(1, 0.5, -0.1, 0.02)  # Single cluster
  } else if (n_clusters == 2) {
    true_beta[,1] <- c(1, 0.8, -0.2, 0.01)   # Cluster 1: increasing then flattening
    true_beta[,2] <- c(3, -0.5, 0.1, -0.02)  # Cluster 2: decreasing curve
  } else if (n_clusters == 3) {
    true_beta[,1] <- c(1, 0.8, -0.2, 0.01)   # Cluster 1
    true_beta[,2] <- c(3, -0.5, 0.1, -0.02)  # Cluster 2
    true_beta[,3] <- c(0, 1.7, -0.3, 0.03)   # Cluster 3: steeper curve
    true_beta[,3] <- c(3, -0.75, 0.1, -0.02)   # Cluster 3: steeper curve
  } else {
    # Random patterns if more than 3 clusters specified
    for (k in 1:n_clusters) {
      true_beta[,k] <- runif(4, min = -2, max = 2)
    }
  }
  
  # Assign clusters to subjects
  cluster_assign_true <- sample(1:n_clusters, size = n_ids, replace = TRUE, 
                               prob = rep(1/n_clusters, n_clusters))
  
  # Generate data
  data <- data.frame()
  for (i in 1:n_ids) {
    cluster <- cluster_assign_true[i]
    x <- seq(0, 4, length.out = time_points)
    x2 <- x^2
    x3 <- x^3
    mu <- cbind(1, x, x2, x3) %*% true_beta[,cluster]
    y <- rnorm(time_points, mean = mu, sd = true_sd[cluster])
    
    data <- rbind(data, data.frame(
      id = i,
      x = x,
      y = y,
      true_cluster = cluster
    ))
  }
  
  # Add some noise covariates (optional)
  data$cov1 <- rnorm(nrow(data))  # Continuous covariate
  data$cov2 <- sample(0:1, nrow(data), replace = TRUE)  # Binary covariate
  
  return(list(
    data = data,
    true_beta = true_beta,
    true_sd = true_sd,
    true_clusters = cluster_assign_true
  ))
}