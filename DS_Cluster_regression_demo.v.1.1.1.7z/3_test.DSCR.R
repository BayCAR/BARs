#source("C:/Users/shpry/Desktop/WFH/Heymsfield/NPH/CGM/R/FUN.DSCR.R")
#source("C:/Users/shpry/Desktop/WFH/Heymsfield/NPH/CGM/R/FUN.generate.data.R")
source("H:/WFH/Heymsfield/NPH/DXA and CGM/R2/FUN.DSCR.v.1.1.R")
source("H:/WFH/Heymsfield/NPH/DXA and CGM/R2/FUN.generate.data.R")

ns=300; tps=8; T.cluster=3; try.cluster=5; n.poly=3

# Generate test data with 2 clusters
test_data <- generate_cluster_data(n_ids = ns, time_points = tps, n_clusters = T.cluster)

# View the structure of the generated data
head(test_data$data) 

test_data$data$x[test_data$data$id<12]=  test_data$data$x[test_data$data$id<12]-rnorm(sum(test_data$data$id<22))*.2
test_data$data$x =  test_data$data$x -rnorm(nrow(test_data$data))*.1

  test_data
  
# Plot the true clusters
library(ggplot2) 
  ggplot(test_data$data, aes(x = x, y = y, group = id, color = factor(true_cluster))) +
  geom_line(alpha = 0.5) +
   stat_summary(aes(group = true_cluster), color=1, fun = mean, geom = "line", size = 3) +
   stat_summary(aes(group = true_cluster), color="darkgreen", fun = mean, geom = "line", size = 2.5) +
   stat_summary(aes(group = true_cluster), fun = mean, geom = "line", size = 2) +
    labs(title = "Simulated Data with True Clusters", 
       color = "True Cluster") +
  theme_minimal()


# Test the clustering functions
init_result <- FUN.Beta.est(test_data$data[,1:3], kluster = try.cluster)
cr_result <- FUN.cr(data = test_data$data[,1:3], n.poly=n.poly, equal.variance = TRUE,
                   kluster = try.cluster, 
                   Beta = init_result$Beta)
 
print(paste("Marginal log-likelihood:", cr_result$marg_llk))
print(paste("Full log-likelihood:", cr_result$llk))

table(cr_result$cluster_assign, test_data$data$true_cluster)

# Compare with true clusters
table(Predicted = cr_result$cluster_assign[seq(1, nrow(test_data$data), by = tps)], 
      True = test_data$true_clusters)

test_data$data$cluster_assign=cr_result$cluster_assign

ggplot(test_data$data, aes(x = x, y = y, group = id, color = factor(cluster_assign))) +
  geom_line(alpha = 0.5) +
  stat_summary(aes(group = cluster_assign), color=1, fun = mean, geom = "line", size = 3) +
  stat_summary(aes(group = cluster_assign), color="darkgreen", fun = mean, geom = "line", size = 2.5) +
  stat_summary(aes(group = cluster_assign), fun = mean, geom = "line", size = 2) +
  labs(title = "Simulated Data with assigned Clusters", 
       color = "Cluster assigned") +
  theme_minimal()






































































########################
kk=5
# Test cluster selection
cluster_selection <- FUN.select_clusters(test_data$data[,1:3], max_clusters = kk, n.poly = n.poly, equal.variance = TRUE)


# Plot AIC/BIC values
plot(1:kk, cluster_selection$aic_values, type = "b", col = "red", 
     xlab = "Number of clusters", ylab = "Value", 
     main = "Cluster Selection Criteria", ylim=c(min(c(cluster_selection$aic_values,cluster_selection$bic_values), na.rm=TRUE), 
                                                 max(c(cluster_selection$aic_values,cluster_selection$bic_values), na.rm=TRUE)))
lines(1:kk, cluster_selection$bic_values, type = "b", col = "blue")
legend("topleft", legend = c("AIC", "BIC"), col = c("red", "blue"), lty = 1)

# Show optimal cluster count
cat("Optimal number of clusters (by BIC):", cluster_selection$optimal_k, "\n")

try.cluster=cluster_selection$optimal_k

# Test with covariates
init_result_cov <- FUN.Beta.est(test_data$data[,c("id","x","y")], kluster = try.cluster)
cr_result_cov <- FUN.cr(data = test_data$data, 
                       kluster = try.cluster, 
                       Beta = init_result_cov$Beta,
                       contcov = "cov1",
                       catcov = "cov2")

# Compare results with covariates
table(Predicted = cr_result_cov$cluster_assign[seq(1, nrow(test_data$data), by = tps)], 
      True = test_data$true_clusters)


test_data$data$cluster_assign=cr_result_cov$cluster_assign

ggplot(test_data$data, aes(x = x, y = y, group = id, color = factor(cluster_assign))) +
  geom_line(alpha = 0.5) +
  stat_summary(aes(group = cluster_assign), color=1, fun = mean, geom = "line", size = 3) +
  stat_summary(aes(group = cluster_assign), color="darkgreen", fun = mean, geom = "line", size = 2.5) +
  stat_summary(aes(group = cluster_assign), fun = mean, geom = "line", size = 2) +
  labs(title = "Simulated Data with assigned Clusters", 
       color = "Cluster assigned") +
  theme_minimal()


###################################
####################################
####################################
# Extract cluster coefficients
beta_matrix <- cr_result_cov$Beta
n_clusters <- ncol(beta_matrix)

# Create prediction data
x_range <- seq(min(test_data$data$x), max(test_data$data$x), length.out = 100)
cluster_fits <- data.frame()

for(cl in 1:n_clusters) {
  y_pred <- beta_matrix[1, cl] +                # Intercept
    beta_matrix[2, cl] * x_range +      # Linear term
    beta_matrix[3, cl] * x_range^2  +    # Quadratic term
    beta_matrix[4, cl] * x_range^3      # Cubic term
  
  cluster_fits <- rbind(cluster_fits,
                        data.frame(
                          x = x_range,
                          y = y_pred,
                          Cluster = factor(paste("Cluster", cl))
                        ))
}

# Plot with custom cubic fits 



duid=sort(unique(test_data$data$id))
i=1


for (i in 1:length(duid))
{
  data.i=test_data$data[test_data$data$id==duid[i],] 
  if (i==1)
  {plot(data.i$x, (data.i$y),  type="b", col=data.i$cluster_assign+1, xlim=c(min(test_data$data$x), max(test_data$data$x)), ylim=c(-4, 5), 
        xlab="Day", ylab="Exercise minutes", lwd=1 )} else
          
        {points(data.i$x, (data.i$y), type="b", col=data.i$cluster_assign+1, lwd=1)}  
  
  
}


for (j in 1:try.cluster)
{
  ci=cluster_fits[cluster_fits$Cluster==paste0("Cluster ", j),]
  lines(ci$x,  (ci$y), lwd=5, col=1)
  lines(ci$x,  (ci$y), lwd=3, col=j+1)
} 
