#source("C:/Users/shpry/Desktop/WFH/Heymsfield/NPH/CGM/R/FUN.DSCR.R")
#source("C:/Users/shpry/Desktop/WFH/Heymsfield/NPH/CGM/R/FUN.generate.data.R")
source("H:/WFH/Heymsfield/NPH/DXA and CGM/R2/FUN.DSCR.v.1.R")
source("H:/WFH/Heymsfield/NPH/DXA and CGM/R2/FUN.generate.data.R")

ns=300; tps=8; T.cluster=3; n.cluster=5

# Generate test data with 2 clusters
test_data <- generate_cluster_data(n_ids = ns, time_points = tps, n_clusters = T.cluster)

# View the structure of the generated data
head(test_data$data) 

test_data$data$x[test_data$data$id<12]=  test_data$data$x[test_data$data$id<12]-rnorm(sum(test_data$data$id<22))*.2
test_data$data$x =  test_data$data$x -rnorm(nrow(test_data$data))*.1

  test_data
  
# Plot the true clusters
library(ggplot2) 
  ggplot(test_data$data, aes(x = x, y = y, group = id, color = factor(true_cluster))) +
  geom_line(alpha = 0.5) +
   stat_summary(aes(group = true_cluster), color=1, fun = mean, geom = "line", size = 3) +
   stat_summary(aes(group = true_cluster), color="darkgreen", fun = mean, geom = "line", size = 2.5) +
   stat_summary(aes(group = true_cluster), fun = mean, geom = "line", size = 2) +
    labs(title = "Simulated Data with True Clusters", 
       color = "True Cluster") +
  theme_minimal()


# Test the clustering functions
init_result <- FUN.Beta.est(test_data$data[,1:3], kluster = n.cluster)
cr_result <- FUN.cr(data = test_data$data[,1:3], 
                   kluster = n.cluster, 
                   Beta = init_result$Beta)
 
print(paste("Marginal log-likelihood:", cr_result$marg_llk))
print(paste("Full log-likelihood:", cr_result$llk))

table(cr_result$cluster_assign, test_data$data$true_cluster)

# Compare with true clusters
table(Predicted = cr_result$cluster_assign[seq(1, nrow(test_data$data), by = tps)], 
      True = test_data$true_clusters)

test_data$data$cluster_assign=cr_result$cluster_assign

ggplot(test_data$data, aes(x = x, y = y, group = id, color = factor(cluster_assign))) +
  geom_line(alpha = 0.5) +
  stat_summary(aes(group = cluster_assign), color=1, fun = mean, geom = "line", size = 3) +
  stat_summary(aes(group = cluster_assign), color="darkgreen", fun = mean, geom = "line", size = 2.5) +
  stat_summary(aes(group = cluster_assign), fun = mean, geom = "line", size = 2) +
  labs(title = "Simulated Data with assigned Clusters", 
       color = "Cluster assigned") +
  theme_minimal()



kk=5
# Test cluster selection
cluster_selection <- FUN.select_clusters(test_data$data[,1:3], max_clusters = kk)

# Plot AIC/BIC values
plot(1:kk, cluster_selection$aic_values, type = "b", col = "red", 
     xlab = "Number of clusters", ylab = "Value", 
     main = "Cluster Selection Criteria", ylim=c(min(c(cluster_selection$aic_values,cluster_selection$bic_values), na.rm=TRUE), 
                                                 max(c(cluster_selection$aic_values,cluster_selection$bic_values), na.rm=TRUE)))
lines(1:kk, cluster_selection$bic_values, type = "b", col = "blue")
legend("topleft", legend = c("AIC", "BIC"), col = c("red", "blue"), lty = 1)

# Show optimal cluster count
cat("Optimal number of clusters (by BIC):", cluster_selection$optimal_k, "\n")

# Test with covariates
init_result_cov <- FUN.Beta.est(test_data$data[,c("id","x","y")], kluster = n.cluster)
cr_result_cov <- FUN.cr(data = test_data$data, 
                       kluster = n.cluster, 
                       Beta = init_result_cov$Beta,
                       contcov = "cov1",
                       catcov = "cov2")

# Compare results with covariates
table(Predicted = cr_result_cov$cluster_assign[seq(1, nrow(test_data$data), by = tps)], 
      True = test_data$true_clusters)


test_data$data$cluster_assign=cr_result_cov$cluster_assign

ggplot(test_data$data, aes(x = x, y = y, group = id, color = factor(cluster_assign))) +
  geom_line(alpha = 0.5) +
  stat_summary(aes(group = cluster_assign), color=1, fun = mean, geom = "line", size = 3) +
  stat_summary(aes(group = cluster_assign), color="darkgreen", fun = mean, geom = "line", size = 2.5) +
  stat_summary(aes(group = cluster_assign), fun = mean, geom = "line", size = 2) +
  labs(title = "Simulated Data with assigned Clusters", 
       color = "Cluster assigned") +
  theme_minimal()

